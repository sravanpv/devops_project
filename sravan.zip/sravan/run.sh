#!/bin/sh

terraform $1 -var access_key=****** -var secret_key=****** -no-color
