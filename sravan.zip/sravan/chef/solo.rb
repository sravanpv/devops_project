file_cache_path "/home/ec2-user/chef"
cookbook_path "/home/ec2-user/chef/cookbooks"
json_attribs "/home/ec2-user/chef/node.json"
