service 'httpd' do
	action [ :enable, :start ]
end
